const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const app = express();
const port = process.env.PORT || 3000;

// Constants
const OFFLINE_THRESHOLD = 300; // 5 minutes in seconds
const CLEANUP_INTERVAL = 5 * 60 * 1000; // 5 minutes in ms

// Middleware
app.use(cors());
app.use(express.json());

// Initialize database
const db = new sqlite3.Database('./miners.db', (err) => {
    if (err) {
        console.error('Database connection error:', err.message);
    } else {
        console.log('Connected to the SQLite database');
    }
});

// Create or alter table
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS miners (
        id TEXT PRIMARY KEY,
        name TEXT UNIQUE,
        ip TEXT,
        version TEXT,
        lastSeen INTEGER,
        uptime TEXT,
        status TEXT CHECK(status IN ('online', 'offline', 'warning')),
        hashrate TEXT,
        temperature INTEGER,
        power INTEGER,
        roomLevel TEXT,
        lastUpdated INTEGER
    )`, () => {
        // Check for missing columns
        const columnsToAdd = [
            {name: 'hashrate', type: 'TEXT', defaultValue: "'0 TH/s'"},
            {name: 'temperature', type: 'INTEGER', defaultValue: '0'},
            {name: 'power', type: 'INTEGER', defaultValue: '0'},
            {name: 'roomLevel', type: 'TEXT', defaultValue: "'unknown'"},
            {name: 'uptime', type: 'TEXT', defaultValue: "'0m'"},
            {name: 'status', type: 'TEXT', defaultValue: "'offline'"}
        ];

        db.all("PRAGMA table_info(miners)", [], (err, rows) => {
            if (err) {
                console.error('Error getting table info:', err);
                return;
            }
            
            const existingColumns = rows.map(row => row.name);
            
            columnsToAdd.forEach(col => {
                if (!existingColumns.includes(col.name)) {
                    db.run(`ALTER TABLE miners ADD COLUMN ${col.name} ${col.type} DEFAULT ${col.defaultValue}`, err => {
                        if (err) {
                            console.error(`Error adding column ${col.name}:`, err);
                        } else {
                            console.log(`Added column ${col.name}`);
                        }
                    });
                }
            });
        });
    });
});

// Helper function to calculate status
function calculateStatus(lastSeen) {
    if (!lastSeen) return 'offline';
    const currentTime = Math.floor(Date.now() / 1000);
    return (currentTime - lastSeen) <= OFFLINE_THRESHOLD ? 'online' : 'offline';
}

// Automatic offline miner cleanup
function checkOfflineMiners() {
    const cutoff = Math.floor(Date.now() / 1000) - OFFLINE_THRESHOLD;
    db.run(
        `UPDATE miners SET status = 'offline' WHERE lastSeen < ? AND status = 'online'`,
        [cutoff],
        (err) => {
            if (err) {
                console.error('Error marking offline miners:', err);
            } else {
                console.log('Marked stale miners as offline');
            }
        }
    );
}

// Start cleanup interval
setInterval(checkOfflineMiners, CLEANUP_INTERVAL);

// Heartbeat endpoint
app.post('/api/heartbeat', (req, res) => {
    const {
        id,
        name,
        ip,
        version = '0.0.0',
        hashrate = '0 TH/s',
        temperature = 0,
        power = 0,
        roomLevel = 'unknown'
    } = req.body;

    if (!name || !ip) {
        return res.status(400).json({ error: 'Name and IP are required' });
    }

    const timestamp = Math.floor(Date.now() / 1000);
    
    db.get(`SELECT lastSeen FROM miners WHERE name = ?`, [name], (err, row) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        const status = calculateStatus(row?.lastSeen);

        db.run(
            `INSERT INTO miners (
                id, name, ip, version, lastSeen, uptime, status, 
                hashrate, temperature, power, roomLevel, lastUpdated
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET
                ip = excluded.ip,
                version = excluded.version,
                lastSeen = excluded.lastSeen,
                uptime = CASE 
                    WHEN excluded.lastSeen > lastSeen THEN 
                        CASE 
                            WHEN uptime = '0m' THEN '1m' 
                            ELSE printf('%dm', CAST(SUBSTR(uptime, 1, LENGTH(uptime)-1) AS INTEGER) + (excluded.lastSeen - lastSeen)/60)
                        END
                    ELSE uptime
                END,
                status = excluded.status,
                hashrate = excluded.hashrate,
                temperature = excluded.temperature,
                power = excluded.power,
                roomLevel = excluded.roomLevel,
                lastUpdated = excluded.lastUpdated`,
            [
                id || name,
                name,
                ip,
                version,
                timestamp,
                '1m',
                status,
                hashrate,
                temperature,
                power,
                roomLevel,
                timestamp
            ],
            (err) => {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ error: 'Database error' });
                }
                res.json({ 
                    status: 'success', 
                    updated: timestamp,
                    message: 'Heartbeat recorded'
                });
            }
        );
    });
});

// Get all miners
app.get('/api/miners', (req, res) => {
    db.all(`SELECT * FROM miners`, [], (err, rows) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        
        const currentTime = Math.floor(Date.now() / 1000);
        const miners = rows.map(row => ({
            ...row,
            status: calculateStatus(row.lastSeen)
        }));
        
        // Group by roomLevel
        const roomGroups = {};
        miners.forEach(miner => {
            if (miner.roomLevel) {
                if (!roomGroups[miner.roomLevel]) {
                    roomGroups[miner.roomLevel] = [];
                }
                roomGroups[miner.roomLevel].push(miner);
            }
        });
        
        res.json({
            status: 'success',
            data: {
                miners,
                roomGroups,
                totals: {
                    online: miners.filter(m => m.status === 'online').length,
                    offline: miners.filter(m => m.status === 'offline').length,
                    all: miners.length
                },
                lastUpdated: currentTime
            }
        });
    });
});

// Get single miner
app.get('/api/miners/:name', (req, res) => {
    const { name } = req.params;
    
    db.get(`SELECT * FROM miners WHERE name = ?`, [name], (err, row) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        
        if (!row) {
            return res.status(404).json({ error: 'Miner not found' });
        }
        
        res.json({
            status: 'success',
            data: {
                ...row,
                status: calculateStatus(row.lastSeen)
            }
        });
    });
});

// Start server
app.listen(port, () => {
    console.log(`Miner tracking server running on port ${port}`);
    console.log(`API Endpoints:`);
    console.log(`- POST   /api/heartbeat - Send miner data`);
    console.log(`- GET    /api/miners - Get all miners`);
    console.log(`- GET    /api/miners/:name - Get specific miner`);
});